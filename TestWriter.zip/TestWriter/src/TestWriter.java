import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;


public class TestWriter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("out.txt"); //Mi aggancio al file
		try {
			
			
			OutputStream os = new FileOutputStream(file); 
			
			int b;
			
			do {
				b=System.in.read(); 
				os.write(b);
			} while (b!='\n');
			
			os.close();
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
